#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

#include <utility>

int t4_solve (student *arr, int n);

#endif
