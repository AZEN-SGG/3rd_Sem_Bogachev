#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

int t6_solve(student *arr, int n, student& x);

#endif
