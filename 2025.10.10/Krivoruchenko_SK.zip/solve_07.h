#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

int t7_solve(student *arr, int n, student& x);

#endif
