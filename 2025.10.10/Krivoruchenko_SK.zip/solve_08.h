#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

int t8_solve(student *arr, int n, student& x);

#endif
