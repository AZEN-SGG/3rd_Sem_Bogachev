#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

int t9_solve(student *arr, int n, student& x);

#endif
