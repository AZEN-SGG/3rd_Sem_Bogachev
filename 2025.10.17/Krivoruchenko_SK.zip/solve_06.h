#ifndef SOLVE_H
#define SOLVE_H

#include "list.h"

int t6_solve(list_node *head);

#endif
