#ifndef SOLVE_H
#define SOLVE_H

#include "list.h"

int t3_solve(list_node *head);

#endif
