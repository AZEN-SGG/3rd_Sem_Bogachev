#ifndef SOLVE_H
#define SOLVE_H

#include "list.h"

int t8_solve(list_node *head);

#endif
