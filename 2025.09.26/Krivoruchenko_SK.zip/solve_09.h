#ifndef SOLVE_H
#define SOLVE_H

#include "data.h"

#include <utility>

void t9_solve (data *arr, int n);
int findIndex (data *arr, int n, int m); 

#endif
