#ifndef SOLVE_H
#define SOLVE_H

#include "data.h"

void t6_solve(data *arr, int n);
int find(data *arr, int n, data& x);
void append(data *arr, int n, data x, int index);

#endif
