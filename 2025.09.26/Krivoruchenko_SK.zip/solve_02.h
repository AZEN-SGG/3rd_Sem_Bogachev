#ifndef SOLVE_H
#define SOLVE_H

#include "data.h"

void t2_solve(data *arr_a, data *arr_b, data *arr_c, int n, int m);

#endif
