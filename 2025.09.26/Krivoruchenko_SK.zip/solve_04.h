#ifndef SOLVE_H
#define SOLVE_H

#include "data.h"

#include <utility>

void t4_solve(data *arr, int n);

#endif
