#ifndef SOLVE_H
#define SOLVE_H

#include "data.h"

#include <utility>

int t3_solve(data *arr, int n, int m);

#endif
