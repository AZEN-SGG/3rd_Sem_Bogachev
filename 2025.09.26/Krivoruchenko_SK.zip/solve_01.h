#ifndef SOLVE_H
#define SOLVE_H

#include "data.h"

int t1_solve(data *a, int n, data& x);

#endif
