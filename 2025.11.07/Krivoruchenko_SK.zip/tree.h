#ifndef TREE_H
#define TREE_H

#include "student.h"

#include <cstdio>

class tree;
class tree_node : public student
{
	private:
		tree_node * left = nullptr;
		tree_node * right = nullptr;
	public:
		tree_node () = default;
		tree_node (const tree_node&) = delete;
		tree_node (tree_node&& x) : student ((student&&)x)
		{
			erase_links();
			x.erase_links();
		}
		~tree_node ()
		{
			erase_links();
		}
		
		tree_node& operator= (const tree_node&) = delete;
		tree_node& operator= (tree_node&& x)
		{
			if (this == &x)
				return *this;
			(student&&)*this = (student&&)x;

			erase_links();
			x.erase_links();

			return *this;
		}

		friend class tree;
	private:
		void erase_links () { left = nullptr; right = nullptr; }
};

class tree
{
	private:
		tree_node * root = nullptr;
	public:
		tree () = default;
		tree (const tree&) = delete;
		tree (tree&& x)
		{
			root = x.root;
			x.root = nullptr;
		}
		~tree ()
		{
			delete_subtree(root);
			root = nullptr;
		}

		tree& operator= (const tree&) = delete;
		tree& operator= (tree&& x)
		{
			if (this == &x)
				return *this;
			delete_subtree(root);
			root = x.root;
			x.root = nullptr;
			return *this;
		}

		void print (unsigned int r = 10, FILE *fp = stdout) const
		{
			print_subtree(root, 0, r, fp);
		}
		io_status read (FILE *fp = stdin, unsigned int max_read = -1);
		io_status read_file (char *filename, unsigned int max_read = -1);

        // Side
        int num_level (int level);
        int depth_tree (int *max_diff);
        int find_min ();
        int del_with_value (const int value);

        // Solves
        int t1_solve ();
        int t2_solve ();
        int t3_solve ();
        int t4_solve ();
        int t5_solve ();
        int t6_solve ();
	private:
		static void delete_subtree (tree_node *curr)
        {
            if (curr == nullptr)
                return;
            delete_subtree(curr->left);
            delete_subtree(curr->right);
            delete curr;
        }
        static void print_subtree (tree_node *curr, int level, int r, FILE *fp = stdout)
        {
            if ((curr == nullptr) || (level > r))
                return;
            int spaces = level << 1;
            for (int i = 0 ; i < spaces ; i++)
                fprintf(fp, " ");
            curr->print(fp);
            print_subtree(curr->left, level + 1, r, fp);
            print_subtree(curr->right, level + 1, r, fp);
        }
        static void add_node_subtree (tree_node *curr, tree_node *x)
        {
            if (*x < *curr)
            {
                if (curr->left == nullptr)
                    curr->left = x;
                else
                    add_node_subtree(curr->left, x);
            } else
            {
                if (curr->right == nullptr)
                    curr->right = x;
                else
                    add_node_subtree(curr->right, x);
            }
        }
};

#endif // TREE_H
