#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

#include <utility>

void t5_solve(student *arr, int n);
int minimum(student *a, int n);

#endif
