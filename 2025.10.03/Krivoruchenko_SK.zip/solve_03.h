#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

#include <utility>

int t3_solve(student *arr, int n, int m); 

#endif
