#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

int t1_solve(student *a, int n, student& x);

#endif
