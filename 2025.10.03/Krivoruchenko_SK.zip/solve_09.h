#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

#include <utility>

void t9_solve (student *arr, int n);
int findIndex (student *arr, int n, int m); 

#endif
