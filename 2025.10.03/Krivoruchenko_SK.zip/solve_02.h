#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

void t2_solve(student *arr_a, student *arr_b, student *arr_c, int n, int m);

#endif
