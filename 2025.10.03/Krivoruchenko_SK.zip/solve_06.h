#ifndef SOLVE_H
#define SOLVE_H

#include "student.h"

#include <utility>

void t6_solve(student *arr, int n);
int find(student *arr, int n, student& x);
void append(student *arr, int n, int index);

#endif
